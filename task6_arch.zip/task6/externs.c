extern double F1(double x);
extern double F2(double x);
extern double F3(double x);
extern double H1(double x);
extern double H2(double x);
extern double H3(double x);
